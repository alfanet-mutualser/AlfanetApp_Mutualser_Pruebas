﻿

//    $(function () {
//        $(".fechaInicial").datepicker({
//            minDate: 0,
//            dateFormat: 'dd/mm/yy'
//        });
//    });

//    $(function () {
//        $(".fechaFinal").datepicker({
//            minDate: 0,
//            dateFormat: 'dd/mm/yy'
//        });
//    });
