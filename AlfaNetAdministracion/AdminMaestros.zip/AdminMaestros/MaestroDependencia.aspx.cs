﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class _MaestroDependencia : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
            this.TCDependencia.ActiveTabIndex = 0;
        }
        else
        {
            TextBox TxtBox = (TextBox)DVDependencia.FindControl("TextBox2");
            RadioButtonList rblst = (RadioButtonList)DVDependencia.FindControl("RbtnLstSelPadre");

            if (rblst != null)
            {
                if (rblst.SelectedValue.ToString() == "0")
                {
                    TxtBox.Visible = false;
                }
                else
                {
                    TxtBox.Visible = true;
                }

            }

        }    
    }

    protected void DVDependencia_DataBound(Object sender, EventArgs e)
    {
        if (this.DVDependencia.DataItemCount.ToString() == "0")
        {
            this.DVDependencia.ChangeMode(DetailsViewMode.Insert);
        }
        else if (this.DVDependencia.CurrentMode == DetailsViewMode.ReadOnly)
        {
            Label Lb = (Label)DVDependencia.FindControl("Label5");
            if (Lb.Text == "1")
            {
                CheckBox Ch = (CheckBox)DVDependencia.FindControl("CheckBox1");
                Ch.Checked = true;
                Ch.Enabled = false;
            }
            Label LbDT = (Label)DVDependencia.FindControl("Label50");
            if (LbDT.Text == "1")
            {
                CheckBox ChDT = (CheckBox)DVDependencia.FindControl("CheckBox10");
                ChDT.Checked = true;
                ChDT.Enabled = false;
            }
        }
        else if (this.DVDependencia.CurrentMode == DetailsViewMode.Edit)
        {
            Label LblCodProce = (Label)DVDependencia.FindControl("Label1");

            DSDependenciaSQLTableAdapters.Dependencia_ReadExisteDependenciaTableAdapter TADependenciaExiste = new DSDependenciaSQLTableAdapters.Dependencia_ReadExisteDependenciaTableAdapter();
            DSDependenciaSQL.Dependencia_ReadExisteDependenciaDataTable DTDependenciaciaExiste = new DSDependenciaSQL.Dependencia_ReadExisteDependenciaDataTable();

            DTDependenciaciaExiste = TADependenciaExiste.GetDependencia_ReadExisteDependencia(LblCodProce.Text);

            Label LblProce = (Label)DVDependencia.FindControl("Label2");
            TextBox TxtProce = (TextBox)DVDependencia.FindControl("TextBox1");
            Label LblProceMsg = (Label)DVDependencia.FindControl("Label13");

            if (DTDependenciaciaExiste.Count == 0)
            {
                LblProce.Visible = false;
                TxtProce.Visible = true;
                LblProceMsg.Visible = false;
            }
            else
            {
                LblProce.Visible = true;
                LblProceMsg.Visible = true;
                TxtProce.Visible = true;  //false
            }            

            TextBox Txt = (TextBox)DVDependencia.FindControl("TextBox5");
            if (Txt.Text == "1")
            {
                CheckBox Ch = (CheckBox)DVDependencia.FindControl("CheckBox1");
                Ch.Checked = true;
                Ch.Enabled = true;
            }

            TextBox TxtDT = (TextBox)DVDependencia.FindControl("TextBox50");
            if (TxtDT.Text == "1")
            {
                CheckBox ChDT = (CheckBox)DVDependencia.FindControl("CheckBox10");
                ChDT.Checked = true;
                ChDT.Enabled = true;
            }
            TextBox Txt2 = (TextBox)DVDependencia.FindControl("TextBox2");
            if (Txt2.Text != "")
            {
                RadioButtonList rblPadre = (RadioButtonList)DVDependencia.FindControl("RbtnLstSelPadre");
                rblPadre.SelectedValue = "1";
                Txt2.Visible = true;
            }

        }

    }

    protected void ImgBtnFind_Click(object sender, ImageClickEventArgs e)
    {
        if (this.TxtDependencia.Text != "")
        {
            if (this.TxtDependencia.Text.Contains(" | "))
            {
                this.HFCodigoSeleccionado.Value = TxtDependencia.Text.Remove(TxtDependencia.Text.IndexOf(" | "));
                this.DVDependencia.ChangeMode(DetailsViewMode.ReadOnly);
                                                             
                this.GVDependenciaPermiso.DataBind();

                DSDependenciaSQLTableAdapters.Dependencia_ReadDependenciaByIdTableAdapter ObjTADep = new DSDependenciaSQLTableAdapters.Dependencia_ReadDependenciaByIdTableAdapter();
                DSDependenciaSQL.Dependencia_ReadDependenciaByIdDataTable DTDependencia = new DSDependenciaSQL.Dependencia_ReadDependenciaByIdDataTable();
                DTDependencia = ObjTADep.GetData(HFCodigoSeleccionado.Value); 
                               
                DataRow[] rows = DTDependencia.Select();

                this.RbtnLstPermiso.SelectedValue = rows[0].ItemArray[5].ToString().Trim();

            }
        }
    }

    protected void ImgBtnEditDependencia_Click(object sender, ImageClickEventArgs e)
    {
            
                CheckBox Ch = (CheckBox)DVDependencia.FindControl("CheckBox1");
                if (Ch.Checked == true)
                {
                    TextBox Txt = (TextBox)DVDependencia.FindControl("TextBox5");
                    Txt.Text = "1";
                    //if (Txt.Text == "1")
                    //{
                    this.DependenciaByIdDataSource.UpdateParameters["DependenciaHabilitar"].DefaultValue = "1";
                    //}
                }
                else
                {
                    TextBox Txt = (TextBox)DVDependencia.FindControl("TextBox5");
                    Txt.Text = "0";
                    this.DependenciaByIdDataSource.UpdateParameters["DependenciaHabilitar"].DefaultValue = "0";
                }
                CheckBox ChDT = (CheckBox)DVDependencia.FindControl("CheckBox10");
                if (ChDT.Checked == true)
                {
                    TextBox TxtDT = (TextBox)DVDependencia.FindControl("TextBox50");
                    TxtDT.Text = "1";
                    this.DependenciaByIdDataSource.UpdateParameters["DistriTareas"].DefaultValue = "1";
                }
                else
                {
                    TextBox TxtDT = (TextBox)DVDependencia.FindControl("TextBox50");
                    TxtDT.Text = "0";
                    this.DependenciaByIdDataSource.UpdateParameters["DistriTareas"].DefaultValue = "0";
                }

                RadioButtonList rblst = (RadioButtonList)DVDependencia.FindControl("RbtnLstSelPadre");
                if (rblst != null)
                {
                    if (rblst.SelectedValue.ToString() == "0")
                    {
                        this.DependenciaByIdDataSource.UpdateParameters["DependenciaCodigoPadre"].DefaultValue = "0";
                    }
                    else
                    {
                        TextBox Txt = (TextBox)DVDependencia.FindControl("TextBox2");
                        if (Txt.Text == "")
                        {
                            this.DependenciaByIdDataSource.UpdateParameters["DependenciaCodigoPadre"].DefaultValue = "0";
                        }
                    }
                }
        


        
        this.DependenciaByIdDataSource.UpdateParameters["DependenciaPermiso"].DefaultValue = RbtnLstPermiso.SelectedValue.ToString();
        this.DependenciaByIdDataSource.UpdateParameters["Original_DependenciaCodigo"].DefaultValue = HFCodigoSeleccionado.Value;
        this.DependenciaByIdDataSource.UpdateParameters["DependenciaNombre"].DefaultValue = HFCodigoSeleccionado.Value;
        
    }

    protected void ImgBtnInsertDependencia_Click(object sender, ImageClickEventArgs e)
    {
        CheckBox Ch = (CheckBox)DVDependencia.FindControl("CheckBox1");
        if (Ch.Checked == true)
        {
            TextBox Txt = (TextBox)DVDependencia.FindControl("TextBox5");
            Txt.Text = "1";
            this.DependenciaByIdDataSource.InsertParameters["DependenciaHabilitar"].DefaultValue = "1";
        }
        else
        {
            TextBox Txt = (TextBox)DVDependencia.FindControl("TextBox5");
            Txt.Text = "0";
            this.DependenciaByIdDataSource.InsertParameters["DependenciaHabilitar"].DefaultValue = "0";
        }

        CheckBox ChDT = (CheckBox)DVDependencia.FindControl("CheckBox10");
        if (ChDT.Checked == true)
        {
            TextBox TxtDT = (TextBox)DVDependencia.FindControl("TextBox50");
            TxtDT.Text = "1";
            this.DependenciaByIdDataSource.InsertParameters["DistriTareas"].DefaultValue = "1";
        }
        else
        {
            TextBox TxtDT = (TextBox)DVDependencia.FindControl("TextBox50");
            TxtDT.Text = "0";
            this.DependenciaByIdDataSource.InsertParameters["DistriTareas"].DefaultValue = "0";
        }

        RadioButtonList rblst = (RadioButtonList)DVDependencia.FindControl("RbtnLstSelPadre");
        if (rblst != null)
        {
            if (rblst.SelectedValue.ToString() == "0")
            {
                this.DependenciaByIdDataSource.InsertParameters["DependenciaCodigoPadre"].DefaultValue = "0";
            }
            else
            {
                TextBox Txt = (TextBox)DVDependencia.FindControl("TextBox2");
                if (Txt.Text == "")
                {
                    this.DependenciaByIdDataSource.InsertParameters["DependenciaCodigoPadre"].DefaultValue = "0";
                }
            }
        }

        this.DependenciaByIdDataSource.InsertParameters["DependenciaPermiso"].DefaultValue = RbtnLstPermiso.SelectedValue.ToString();
    }
    
    protected void DVDependencia_ItemInserted(Object sender, DetailsViewInsertedEventArgs e)
    {   
        if (e.Exception != null)
        {
            //Display a user-friendly message
            this.LblMessageBox.Text = "Ocurrio un problema al tratar de adicionar el registro. ";
            Exception inner = e.Exception.InnerException;
            this.LblMessageBox.Text += ErrorHandled.FindError(inner);
            this.LblMessageBox.Text += e.Exception.Message.ToString();
            this.MPEMensaje.Show();

            //Indicate that exception has been handled
            e.ExceptionHandled = true;

            //Keep the row in insert mode
            e.KeepInInsertMode = true;
        }
        else if (e.Exception == null)
        {
            this.DVDependenciaPermiso.DataBind();
            this.GVDependenciaPermiso.DataBind();
            this.LblMessageBox.Text = "Registro Adicionado";
            this.MPEMensaje.Show();
        }
    }

    protected void DVDependencia_ItemUpdated(Object sender, DetailsViewUpdatedEventArgs e)
    {
        if (e.Exception != null)
        {
            //Display a user-friendly message
            this.LblMessageBox.Text = "Ocurrio un problema al tratar de actualizar el registro. ";
            Exception inner = e.Exception.InnerException;
            this.LblMessageBox.Text += ErrorHandled.FindError(inner);
            this.LblMessageBox.Text += e.Exception.Message.ToString();
            this.MPEMensaje.Show();

            //Indicate that exception has been handled
            e.ExceptionHandled = true;

            //Keep the row in edit mode
            e.KeepInEditMode = true;
        }
        else if (e.Exception == null)
        {
            this.DVDependencia.DataBind();
            this.GVDependenciaPermiso.DataBind();
            this.LblMessageBox.Text = "Registro Editado";
            this.MPEMensaje.Show();
        }
    }

    protected void DVDependencia_ItemDeleted(Object sender, DetailsViewDeletedEventArgs e)
    {
        if (e.Exception != null)
        {
            //Display a user-friendly message
            this.LblMessageBox.Text = "Ocurrio un problema al tratar de eliminar el registro. ";
            Exception inner = e.Exception.InnerException;
            this.LblMessageBox.Text += ErrorHandled.FindError(inner);
            this.LblMessageBox.Text += e.Exception.Message.ToString();
            this.MPEMensaje.Show();

            //Indicate that exception has been handled
            e.ExceptionHandled = true;

        }
        else if (e.Exception == null)
        {
            this.DVDependencia.DataBind();
            this.GVDependenciaPermiso.DataBind();
            this.LblMessageBox.Text = "Registro Eliminado";
            this.MPEMensaje.Show();
        }
    }

    protected void GVDependenciaPermiso_RowDeleted(Object sender, GridViewDeletedEventArgs e)
    {
        if (e.Exception != null)
        {
            //Display a user-friendly message
            this.LblMessageBox.Text = "Ocurrio un problema al tratar eliminar el registro. ";
            Exception inner = e.Exception.InnerException;
            this.LblMessageBox.Text += ErrorHandled.FindError(inner);
            this.LblMessageBox.Text += e.Exception.Message.ToString();
            this.MPEMensaje.Show();

            //Indicate that exception has been handled
            e.ExceptionHandled = true;
        }
        else if (e.Exception == null)
        {
            this.DVDependencia.DataBind();
            this.GVDependenciaPermiso.DataBind();
            this.LblMessageBox.Text = "Registro Eliminado";
            this.MPEMensaje.Show();
        }
    }

    protected void TCDependencia_OnActiveTabChanged(Object sender, EventArgs e)
    {
        if (this.TCDependencia.ActiveTabIndex.ToString() == "1")
        {
            if (this.HFCodigoSeleccionado.Value.Length.ToString() == "0")
            {
                this.LblMessageBox.Text = "No ha seleccionado una dependencia";
                this.MPEMensaje.Show();
                
            }
            else
            {
                this.RbtnLstPermiso.Enabled = true;
                //this.Paneldep.Visible = true;
               // this.la
                Label Lb = (Label)DVDependenciaPermiso.FindControl("Label1");
                Lb.Text = HFCodigoSeleccionado.Value;
                //Lab
                //this.DVDependenciaPermiso.FindControl("Label1")
            }
        }
    }

    protected void RadBtnLstFindby_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (this.RadBtnLstFindby.SelectedValue.ToString() == "1")
            this.AutoCompleteDependencia.ServiceMethod = "GetDependenciaByTextnull";
        if (this.RadBtnLstFindby.SelectedValue.ToString() == "2")
            this.AutoCompleteDependencia.ServiceMethod = "GetDependenciaByTextIdnull";
    }


    protected void ImgBtnInsertDependenciaPermiso_Click(object sender, ImageClickEventArgs e)
    {
        TextBox TxtDep = (TextBox)DVDependenciaPermiso.FindControl("TextBox2");
        String DepCod = TxtDep.Text;
        if (DepCod != "")
            {
                if (DepCod.Contains(" | "))
                {
                    DepCod = DepCod.Remove(DepCod.IndexOf(" | "));
                }
            }
            //DSDependenciaSQLTableAdapters.DependenciaPermiso_ReadDependenciaPermisoByIdTableAdapter ObjTADepPer = new DSDependenciaSQLTableAdapters.DependenciaPermiso_ReadDependenciaPermisoByIdTableAdapter();
            //int correcto = ObjTADepPer.Insert(DepCod,this.HFCodigoSeleccionado.Value);
            this.ODSPermisoDependencia.InsertParameters["DependenciaCodigo"].DefaultValue = this.HFCodigoSeleccionado.Value;
            this.ODSPermisoDependencia.InsertParameters["DependenciaPermisoCodigo"].DefaultValue = DepCod;
        //this.ODSPermisoDependencia.Insert();
        //this.ODSPermisoDependencia.InsertParameters["DependenciaCodigo"].DefaultValue = this.HFCodigoSeleccionado.Value;
        //this.GVDependenciaPermiso.DataBind();
        TxtDep.Text = "";
        Label Lb = (Label)DVDependenciaPermiso.FindControl("Label1");
        Lb.Text = HFCodigoSeleccionado.Value;

    }
    protected void ImgBtnDeleteDependenciaPermiso_Click(object sender, ImageClickEventArgs e)
    {
        this.DependenciaByIdDataSource.DeleteParameters["Original_DependenciaCodigo"].DefaultValue = HFCodigoSeleccionado.Value;
        this.TxtDependencia.Text = "";
        this.Label7.Text = "¿Va a eliminar la Dependencia seleccionada esta seguro?" + " ";
        this.MPEPregunta.Show();
    }
    protected void DVDependencia_ItemInserting(object sender, DetailsViewInsertEventArgs e)
    {

    }
    protected void RbtnLstPermiso_SelectedIndexChanged(object sender, EventArgs e)
    {
        DSDependenciaSQLTableAdapters.Dependencia_ReadDependenciaByIdTableAdapter ObjTADep = new DSDependenciaSQLTableAdapters.Dependencia_ReadDependenciaByIdTableAdapter();
        //DSDependenciaSQLTableAdapters.DependenciaTableAdapter ObjTAExp = new DSDependenciaSQLTableAdapters.DependenciaTableAdapter();
        DSDependenciaSQL.Dependencia_ReadDependenciaByIdDataTable DTDependencia = new DSDependenciaSQL.Dependencia_ReadDependenciaByIdDataTable();
        //DSDependenciaSQL.DependenciaDataTable DTDependencia = new DSDependenciaSQL.DependenciaDataTable();
        DTDependencia = ObjTADep.GetDependencia_UpdateDependenciaPermisoBy(HFCodigoSeleccionado.Value, RbtnLstPermiso.SelectedValue);
        //DTDependencia = ObjTAExp.GetDependencia_UpdateDependenciaPermisoBy(HFCodigoSeleccionado.Value, Convert.ToBoolean(RbtnLstPermiso.SelectedValue));


    }
    protected void DVDependenciaPermiso_ItemInserted(Object sender, DetailsViewInsertedEventArgs e)
    {
        if (e.Exception != null)
        {
            //Display a user-friendly message
            this.LblMessageBox.Text = "Ocurrio un problema al tratar de adicionar el registro. ";
            Exception inner = e.Exception.InnerException;
            this.LblMessageBox.Text += ErrorHandled.FindError(inner);
            this.MPEMensaje.Show();

            //Indicate that exception has been handled
            e.ExceptionHandled = true;

            //Keep the row in insert mode
            e.KeepInInsertMode = true;
        }
        else if (e.Exception == null)
        {
            this.DVDependencia.DataBind();
            //this.DVDependenciaPermiso.DataBind();
            //this.GVDependenciaPermiso.DataBind();
            this.LblMessageBox.Text = "Registro Adicionado";
            this.MPEMensaje.Show();
        }

    }
    protected void RbtnLstSelPadre_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void ImgBtnNewDependencia_Click(object sender, ImageClickEventArgs e)
    {
        this.DVDependencia.ChangeMode(DetailsViewMode.Insert);
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        DependenciaBLL Dependencia = new DependenciaBLL();
        bool Correcto;

        try
        {

            Correcto = Dependencia.DeleteDependencia(HFCodigoSeleccionado.Value);
            this.LblMessageBox.Text = "Registro Eliminado";
        }
        catch (Exception Error)
        {
            this.LblMessageBox.Text = "Ocurrio un problema al tratar de eliminar el registro. ";
            this.MPEMensaje.Show();
        }

        //this.DVDepartamento.DataBind();
       
        this.MPEMensaje.Show();
        this.TxtDependencia.Text = "";
    }

    
}

