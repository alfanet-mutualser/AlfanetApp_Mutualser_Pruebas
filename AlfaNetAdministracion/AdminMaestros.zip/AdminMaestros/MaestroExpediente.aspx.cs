﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class _MaestroExpediente : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string Admon = Request["Admon"];
            if (Admon == "S")
            {
                ((MainMaster)this.Master).hidemenu();
            }
            else
            {
                ((MainMaster)this.Master).showmenu();
            }
            this.TCExpediente.ActiveTabIndex = 0;
        }
        else
        {
            TextBox TxtBox = (TextBox)DVExpediente.FindControl("TxtExpedientePadre");
            RadioButtonList rblst = (RadioButtonList)DVExpediente.FindControl("RbtnLstSelPadre");

            if (rblst != null)
            {
                if (rblst.SelectedValue.ToString() == "0")
                {
                    TxtBox.Visible = false;
                }
                else
                {
                    TxtBox.Visible = true;
                }

            }

        }
    }

    protected void DVExpediente_DataBound(Object sender, EventArgs e)
    {
        Label Lb = (Label)DVExpedientePermiso.FindControl("Label1");
        Lb.Text = HFCodigoSeleccionado.Value;



        //Label Lb1 = (Label)DetailsView1.FindControl("Label1");
        //Lb1.Text = HFCodigoSeleccionado.Value;
        /*
        this.MPEMensaje.Show(this.DVExpediente.DefaultMode.ToString());

        if (this.DVExpediente.DataItemCount.ToString() == "0")
        {
            this.DVExpediente.ChangeMode(DetailsViewMode.Insert);
        }

        if (this.DVExpediente.DefaultMode.ToString() == "Insert")
        {
            this.RbtnLstPermiso.Enabled = true;
        }
        */
        //else 
        if (this.DVExpediente.CurrentMode == DetailsViewMode.Edit)
        {
            Label LblCodProce = (Label)DVExpediente.FindControl("Label1");

            DSExpedienteSQLTableAdapters.Expediente_ReadExisteExpedienteTableAdapter TAExpedienteExiste = new DSExpedienteSQLTableAdapters.Expediente_ReadExisteExpedienteTableAdapter();
            DSExpedienteSQL.Expediente_ReadExisteExpedienteDataTable DTExpedienteExiste = new DSExpedienteSQL.Expediente_ReadExisteExpedienteDataTable();
            DTExpedienteExiste = TAExpedienteExiste.GetExpediente_ReadExisteExpediente(LblCodProce.Text);

            Label LblProce = (Label)DVExpediente.FindControl("Label2");
            TextBox TxtProce = (TextBox)DVExpediente.FindControl("TextBox2");
            Label LblProceMsg = (Label)DVExpediente.FindControl("Label13");

            if (DTExpedienteExiste.Count == 0)
            {
                LblProce.Visible = false;
                TxtProce.Visible = true;
                LblProceMsg.Visible = false;
            }
            else
            {
                LblProce.Visible = true;
                LblProceMsg.Visible = true;
                TxtProce.Visible = false;
            }            

            TextBox Txt2 = (TextBox)DVExpediente.FindControl("TxtExpedientePadre");
            if (Txt2.Text != "")
            {
                RadioButtonList rblPadre = (RadioButtonList)DVExpediente.FindControl("RbtnLstSelPadre");
                rblPadre.SelectedValue = "1";
                Txt2.Visible = true;
            }
        }
    }


    protected void ImgBtnFind_Click(object sender, ImageClickEventArgs e)
    {
        if (this.TxtExpediente.Text != "")
        {
            if (this.TxtExpediente.Text.Contains(" | "))
            {
                this.HFCodigoSeleccionado.Value = TxtExpediente.Text.Remove(TxtExpediente.Text.IndexOf(" | "));
                this.DVExpediente.ChangeMode(DetailsViewMode.ReadOnly);
                this.GVExpedientePermiso.DataBind();
                //this.RbtnLstPermiso.SelectedValue =
                //this.DVExpedientePermiso.DataBind();
                //this.RbtnLstPermiso.SelectedValue = 
                DSExpedienteSQLTableAdapters.ExpedienteTableAdapter ObjTAExp = new DSExpedienteSQLTableAdapters.ExpedienteTableAdapter();
                DSExpedienteSQL.ExpedienteDataTable DTExpediente = new DSExpedienteSQL.ExpedienteDataTable();
                DTExpediente = ObjTAExp.GetExpedienteById(HFCodigoSeleccionado.Value);
                DataRow[] rows = DTExpediente.Select();

                this.RbtnLstPermiso.SelectedValue = rows[0].ItemArray[4].ToString().Trim();

                Label Lb = (Label)DVExpedientePermiso.FindControl("Label1");
                Lb.Text = HFCodigoSeleccionado.Value;
                this.RbtnLstPermiso.Enabled = true;
            }
        }
    }


    /*
    protected void ImgBtnInsertPermiso_Click(object sender, ImageClickEventArgs e)
    {
        
        // PRIMER PARAMETRO A INSERTAR
        this.ExpedientePermisoByIdDataSource.InsertParameters["ExpedienteCodigo"].DefaultValue = this.HFCodigoSeleccionado.Value.ToString();

        // SEGUNDO PARAMETRO A INSERTAR
        TextBox TxtBox1 = (TextBox)DVExpedientePermiso.FindControl("TxtDependenciaPermiso");
        RadioButtonList rblst1 = (RadioButtonList)DVExpedientePermiso.FindControl("RbtnLst1");
        if (rblst1 != null)
        {
            if (rblst1.SelectedValue.ToString() == "0")
            {
                this.ExpedientePermisoByIdDataSource.InsertParameters["DependenciaCodigo"].DefaultValue = "-1";
            }
            else
            {
                if (TxtBox1.Text != "")
                {
                    if (TxtBox1.Text.Contains("-"))
                    {
                       this.ExpedientePermisoByIdDataSource.InsertParameters["DependenciaCodigo"].DefaultValue = TxtBox1.Text.Remove(TxtBox1.Text.IndexOf("-"));
                    }
                }
            }
        }

        // TERCER PARAMETRO A INSERTAR
        RadioButtonList rblst2 = (RadioButtonList)DVExpedientePermiso.FindControl("RbtnLst2");
        this.ExpedientePermisoByIdDataSource.InsertParameters["ExpedientePermisoHabilitar"].DefaultValue = rblst2.SelectedValue.ToString();
        

        //this.ExpedientePermisoByIdDataSource.InsertParameters["ExpedienteCodigo"].DefaultValue = "1";
        //this.ExpedientePermisoByIdDataSource.InsertParameters["DependenciaCodigo"].DefaultValue = "1";
        //this.ExpedientePermisoByIdDataSource.InsertParameters["ExpedientePermisoHabilitar"].DefaultValue = "True";  

    }
    */

    protected void ImgBtnEditExpediente_Click(object sender, ImageClickEventArgs e)
    {
        this.ExpedienteByIdDataSource.UpdateParameters["ExpedientePermiso"].DefaultValue = RbtnLstPermiso.SelectedValue.ToString();
    }

    protected void ImgBtnInsertExpediente_Click(object sender, ImageClickEventArgs e)
    {
        TextBox TxtDepPadre = (TextBox)DVExpediente.FindControl("TxtExpedientePadre");
        String DepPadreCod = TxtDepPadre.Text;
        if (DepPadreCod != "")
        {
            if (DepPadreCod.Contains(" | "))
            {
                DepPadreCod = DepPadreCod.Remove(DepPadreCod.IndexOf(" | "));
            }
        }
        this.ExpedienteByIdDataSource.InsertParameters["ExpedienteCodigoPadre"].DefaultValue = DepPadreCod;
        this.ExpedienteByIdDataSource.InsertParameters["ExpedientePermiso"].DefaultValue = RbtnLstPermiso.SelectedValue.ToString();
    }

    protected void DVExpediente_ItemInserted(Object sender, DetailsViewInsertedEventArgs e)
    {

        if (e.Exception != null)
        {
            //Display a user-friendly message
            this.LblMessageBox.Text = "Ocurrio un problema al tratar de adicionar el registro. ";
            Exception inner = e.Exception.InnerException;
            this.LblMessageBox.Text += ErrorHandled.FindError(inner);
            this.LblMessageBox.Text += e.Exception.Message.ToString();
            this.MPEMensaje.Show();

            //Indicate that exception has been handled
            e.ExceptionHandled = true;

            //Keep the row in insert mode
            e.KeepInInsertMode = true;
        }
        else if (e.Exception == null)
        {
            this.DVExpediente.DataBind();
            this.GVExpedientePermiso.DataBind();
            this.LblMessageBox.Text = "Registro Adicionado";
            this.MPEMensaje.Show();
        }
    }

    protected void DVExpediente_ItemUpdated(Object sender, DetailsViewUpdatedEventArgs e)
    {
        if (e.Exception != null)
        {
            //Display a user-friendly message
            this.LblMessageBox.Text = "Ocurrio un problema al tratar de actualizar el registro. ";
            Exception inner = e.Exception.InnerException;
            this.LblMessageBox.Text += ErrorHandled.FindError(inner);
            this.LblMessageBox.Text += e.Exception.Message.ToString();
            this.MPEMensaje.Show();

            //Indicate that exception has been handled
            e.ExceptionHandled = true;

            //Keep the row in edit mode
            e.KeepInEditMode = true;
        }
        else if (e.Exception == null)
        {
            this.DVExpediente.DataBind();
            this.GVExpedientePermiso.DataBind();
            this.LblMessageBox.Text = "Registro Editado";
            this.MPEMensaje.Show();
        }
    }

    protected void DVExpediente_ItemDeleted(Object sender, DetailsViewDeletedEventArgs e)
    {
        if (e.Exception != null)
        {
            //Display a user-friendly message
            this.LblMessageBox.Text = "Ocurrio un problema al tratar de eliminar el registro. ";
            Exception inner = e.Exception.InnerException;
            this.LblMessageBox.Text += ErrorHandled.FindError(inner);
            this.LblMessageBox.Text += e.Exception.Message.ToString();
            this.MPEMensaje.Show();

            //Indicate that exception has been handled
            e.ExceptionHandled = true;

        }
        else if (e.Exception == null)
        {
            this.DVExpediente.DataBind();
            this.GVExpedientePermiso.DataBind();
            this.LblMessageBox.Text = "Registro Eliminado";
            this.MPEMensaje.Show();
            this.DVExpediente.ChangeMode(DetailsViewMode.Insert);
        }
    }

    protected void GVExpedientePermiso_RowDeleted(Object sender, GridViewDeletedEventArgs e)
    {
        if (e.Exception != null)
        {
            //Display a user-friendly message
            this.LblMessageBox.Text = "Ocurrio un problema al tratar eliminar el registro. ";
            Exception inner = e.Exception.InnerException;
            this.LblMessageBox.Text += ErrorHandled.FindError(inner);
            this.LblMessageBox.Text += e.Exception.Message.ToString();
            this.MPEMensaje.Show();

            //Indicate that exception has been handled
            e.ExceptionHandled = true;
        }
        else if (e.Exception == null)
        {
            this.DVExpediente.DataBind();
            this.GVExpedientePermiso.DataBind();
            this.LblMessageBox.Text = "Registro Eliminado";
            this.MPEMensaje.Show();
        }
    }

    protected void TCExpediente_OnActiveTabChanged(Object sender, EventArgs e)
    {
        if (this.TCExpediente.ActiveTabIndex.ToString() == "1")
        {
            if (this.HFCodigoSeleccionado.Value.Length.ToString() == "0")
            {
                this.LblMessageBox.Text = "No ha seleccionado un expediente";
                this.MPEMensaje.Show();

            }
            else
            {
                this.RbtnLstPermiso.Enabled = true;
                //this.Paneldep.Visible = true;
                // this.la
                Label Lb = (Label)DVExpedientePermiso.FindControl("Label1");
                Lb.Text = HFCodigoSeleccionado.Value;
                //Lab
                //this.DVExpedientePermiso.FindControl("Label1")
            }
        }
    }

    protected void RadBtnLstFindby_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (this.RadBtnLstFindby.SelectedValue.ToString() == "1")
            this.AutoCompleteExpediente.ServiceMethod = "GetExpedienteByTextNombrenull";
        if (this.RadBtnLstFindby.SelectedValue.ToString() == "2")
            this.AutoCompleteExpediente.ServiceMethod = "GetExpedienteByTextIdnull";
    }

    protected void RBEnterarA_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (RBEnterarA.SelectedValue == "T")
        {
            this.ListBoxEnterar.Items.Clear();
            this.TxtDependencia1.Text = "";
            this.TxtDependencia1.ReadOnly = true;
            //this.DropDownExtender3.Enabled = false;
            this.ImgBtnAdd.Enabled = false;
            this.ImgBtnDelete.Enabled = false;
            this.ListBoxEnterar.Items.Add("Todas | Todas");
        }
        else
        {
            this.ListBoxEnterar.Items.Clear();
            this.TxtDependencia1.Text = "";
            this.TxtDependencia1.ReadOnly = false;
            //this.DropDownExtender3.Enabled = true;
            this.ImgBtnAdd.Enabled = true;
            this.ImgBtnDelete.Enabled = true;
        }
    }
    protected void ImgBtnAdd_Click(object sender, EventArgs e)
    {
        this.ListBoxEnterar.Items.Add(this.TxtDependencia1.Text.ToString());
        this.TxtDependencia1.Text = "";
        string mExpediente = HFCodigoSeleccionado.Value;

    }
    protected void ImgBtnDelete_Click(object sender, EventArgs e)
    {
        this.ListBoxEnterar.Items.Remove(this.ListBoxEnterar.SelectedItem);
    }

    protected void ImgBtnInsertExpedientePermiso_Click(object sender, ImageClickEventArgs e)
    {
        TextBox TxtDep = (TextBox)DVExpedientePermiso.FindControl("TextBox2");
        String DepCod = TxtDep.Text;
        if (DepCod != "")
        {
            if (DepCod.Contains(" | "))
            {
                DepCod = DepCod.Remove(DepCod.IndexOf(" | "));
            }
        }

        DSExpedienteSQLTableAdapters.ExpedientePermiso_ReadExpedientePermisoTableAdapter ObjTAExpPer = new DSExpedienteSQLTableAdapters.ExpedientePermiso_ReadExpedientePermisoTableAdapter();
        int correcto = ObjTAExpPer.Insert(this.HFCodigoSeleccionado.Value,DepCod);

       // this.ODSPermisoExpediente.InsertParameters.RemoveAt(2);
       // this.ODSPermisoExpediente.InsertParameters["ExpedienteCodigo"].DefaultValue = HFCodigoSeleccionado.Value;
       // this.ODSPermisoExpediente.InsertParameters["DependenciaCodigo"].DefaultValue = DepCod;
        
        this.GVExpedientePermiso.DataBind();
        TxtDep.Text = "";
    }
    protected void ImgBtnDeleteExpedientePermiso_Click(object sender, ImageClickEventArgs e)
    {
        this.ExpedienteByIdDataSource.DeleteParameters["Original_ExpedienteCodigo"].DefaultValue = HFCodigoSeleccionado.Value;
        this.TxtExpediente.Text = "";
        this.Label7.Text = "¿Va a eliminar el Expediente seleccionado esta seguro?" + " ";
        this.MPEPregunta.Show();
    }
    protected void DVExpediente_ItemInserting(object sender, DetailsViewInsertEventArgs e)
    {
        TextBox TxtDepPadre = (TextBox)DVExpediente.FindControl("TxtExpedientePadre");
        String DepPadreCod = TxtDepPadre.Text;
        if (DepPadreCod != "")
        {
            if (DepPadreCod.Contains(" | "))
            {
                DepPadreCod = DepPadreCod.Remove(DepPadreCod.IndexOf(" | "));
                this.ExpedienteByIdDataSource.InsertParameters["ExpedienteCodigoPadre"].DefaultValue = DepPadreCod;
            }

        }
    }
    protected void RbtnLstPermiso_SelectedIndexChanged(object sender, EventArgs e)
    {
        DSExpedienteSQLTableAdapters.ExpedienteTableAdapter ObjTAExp = new DSExpedienteSQLTableAdapters.ExpedienteTableAdapter();
        DSExpedienteSQL.ExpedienteDataTable DTExpediente = new DSExpedienteSQL.ExpedienteDataTable();
        DTExpediente = ObjTAExp.GetExpediente_UpdateExpedientePermisoBy(HFCodigoSeleccionado.Value, Convert.ToBoolean(RbtnLstPermiso.SelectedValue));

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        ExpedienteBLL Expediente = new ExpedienteBLL();
        bool Correcto;

        try
        {

            Correcto = Expediente.DeleteExpediente(HFCodigoSeleccionado.Value);
            this.LblMessageBox.Text = "Registro Eliminado";
        }
        catch (Exception Error)
        {
            this.LblMessageBox.Text = "Ocurrio un problema al tratar de eliminar el registro. ";
            this.MPEMensaje.Show();
        }

        ////this.DVDepartamento.DataBind();
        
        this.MPEMensaje.Show();
        this.TxtExpediente.Text = "";
        //this.TxtExpediente.Text= "";
    }

    
}
   

